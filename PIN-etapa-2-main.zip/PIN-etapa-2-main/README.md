# gh-tf-mio

lanzando v10 con buckets y dinamodb!!

(HINT. armar el bucket S3, y la base dynamodb a mano).

SI se quiere terrafonear, mejor.
